;(function ($) {
    $.fn.autofill.lang = {
        emptyTable: "Sem sugestões...",
        processing: "Processando...",
    }
})(jQuery)
