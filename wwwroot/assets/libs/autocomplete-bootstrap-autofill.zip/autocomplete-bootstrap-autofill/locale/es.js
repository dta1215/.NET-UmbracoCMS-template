;(function ($) {
    $.fn.autofill.lang = {
        emptyTable: "No hay sugerencias...",
        processing: "Procesando...",
    }
})(jQuery)
