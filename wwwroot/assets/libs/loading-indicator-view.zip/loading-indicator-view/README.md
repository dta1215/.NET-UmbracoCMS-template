# LoadingView
LoadingView is a Javascript library using jQuery to implement a simple element loading... anybody can easily use. simply download and start using. For JS user, simply call the function: setLoadingView(...) to use OR setElementLoading(...).   For jQuery lovers simple call -  $.loadingView(options); 

#BASIC jQuery Usage Example

$('.body').loadingView();			//start loadingView 

$('.selector').loadingView({'state':true});		//Or start loadingView

$('.selector').loadingView({'state':false}); 	//Stop LoadingView
