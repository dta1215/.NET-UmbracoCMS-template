stickyMojo
==========

stickyMojo is a contained sticky sidebar plugin for jQuery. It's lightweight, fast, flexible and compatible with Firefox, Chrome, Safari, and IE8+. It will degrade gracefully in older versions of IE. [Here are the instructions](http://mojotech.github.com/stickymojo/).

Credits
==========

[![MojoTech](http://www.mojotech.com/press/logo.png)](http://www.mojotech.com)

License
==========

stickyMojo is Copyright © 2014 MojoTech, LLC. It is free software, and may be redistributed under the terms specified in the LICENSE file.
